
import zipfile

list_files = ['Python2.py', 'Python1.py', 'Python3.py', 'Python4.py']

with zipfile.ZipFile('final.zip', 'w') as zipF:
    for file in list_files:
        zipF.write(file, compress_type=zipfile.ZIP_DEFLATED)

print('The three files has been compressed')
oozuGh0naequ3thathah1cho1ohpufae
